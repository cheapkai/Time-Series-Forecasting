Directory Structure:

#LSTM Experiments 
(Subfolders)

##Data_20_2hyp
###Class_Output_Probs
###Class_Pred_Probs
###Differences
###Inputs
###Outputs
###Preds

##Data_20_4hyp
##Data_50_2hyp
##Data_50_4hyp
##Data_100_2hyp
##Data_100_4hyp
(Subfiles)
##README.md
##graph.py
##LSTM_final.py
##lstm_smooth_2hyp.py
##lstm_smooth_4hyp.py
##output_probabilities_2hyp.py
##output_probabilities_4hyp.py
##prediction_2hyp.py
##prediction_4hyp.py
##pred_probabilities_2hyp.py
##pred_probabilities_4hyp.py